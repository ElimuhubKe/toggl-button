---
name: Integration request
about: Suggest a new service you want to see Toggl Button integrated with.
title: Add integration with SERVICENAME
labels: integration-request
assignees: ''

---

<!-- If you're suggesting changes to an existing integration, please use the "Integration changes" issue template instead! -->

**Link to service:** https://example.com

**Is there a free account option?**: Yes/No

### Describe the solution you'd like

<!-- A clear description of where you'd like to see Toggl Button appear inside the service. Feel free to include a screenshot. Keep in mind that it should be useful to the wider user base. -->

#### Additional context

<!-- Add any other context or helpful information here. Maybe share how this fits into your workflow? -->
