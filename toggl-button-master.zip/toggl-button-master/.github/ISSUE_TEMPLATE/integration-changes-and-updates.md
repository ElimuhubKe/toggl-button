---
name: Integration changes and updates
about: Suggest a change or improvement to an existing integration.
title: Add support for ...
labels: enhancement
assignees: ''

---

<!-- If an integration has broken, please report it as a bug instead. -->

### Describe the changes you'd like

<!-- A clear description of the changes you want to see. Keep in mind that it should be useful to the wider user base. -->

### Relevant links or screenshots

<!-- For example, please tell us how to find the relevant screen within the service if it's a new feature -->

#### Additional context

<!-- Add any other context or helpful information here. Maybe share how this improves your productivity with the integration? -->
