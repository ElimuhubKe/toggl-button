Please follow this guide when creating a new issue. This speeds up the process of replicating the issue and finding a solution.

### Environment details

* Operation system:
* Extension version:

### Expected behavior

### Actual behavior

### Steps to reproduce the behavior

### Additional details

* screenshots or screencapture
